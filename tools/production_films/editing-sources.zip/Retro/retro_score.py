from pathlib import Path
import collections,subprocess,math,wave,numpy as np
D=Path(__file__).parent; SR=32000
def compose(name,secs,bpm,root,seed):
 rng=np.random.default_rng(seed); N=int(SR*secs);channels=np.zeros((N,2)); beat=60/bpm
 def add(track,start,wav,pan=.5):
  i=round(start*SR)
  if i>=N:return
  amount=min(len(wav),N-i)
  track[i:i+amount]+=wav[:amount,None]*np.array([(1-pan)**.5,pan**.5])
 def pnote(m,dur,dec=1.4,kind=0):
  t=np.arange(round(dur*SR))/SR;f=440*2**((m-69)/12);release=np.minimum(1,np.maximum(0,(dur-t)/.085)); env=(1-np.exp(-t*56))*np.exp(-t*dec)*release
  return env*(np.sin(2*np.pi*f*t+(.7 if kind==1 else .29)*np.sin(2*np.pi*2*f*t)*np.exp(-t*5))+.13*np.sin(2*np.pi*2*f*t))
 def kick():
  t=np.arange(round(.23*SR))/SR
  return np.sin(2*np.pi*(49*t+.62*(1-np.exp(-t*32))))*np.exp(-t*15)*np.minimum(1,t/.003)
 def brush(s=.12):
  n=rng.normal(0,.32,int(s*SR)+1);t=np.arange(len(n)-1)/SR
  return np.diff(n)*np.exp(-t*(42 if s>.1 else 73))*np.minimum(1,t/.0014)
 prog=[(0,[0,4,7,11,14]),(-3,[0,3,7,10,14]),(2,[0,3,7,10,14]),(-5,[0,4,7,10,14])]
 for j in range(int(secs/(beat*4))+1):
  dist,notes=prog[j%4]; start=j*4*beat;r=root+dist
  night=name=='retro-glam' or (name=='original-experiences' and start>=14)
  for k in ([0,1.5,2.75] if night else [0,2.5]):
   for q,nt in enumerate(notes):add(channels,start+k*beat+q*.012,.13*pnote(r+12+nt,(1.24 if night else 1.84)*beat,2.1 if night else 1.75,1),.23+q*.135)
  for k,nt in ([(0,0),(.75,12),(1.5,0),(2.5,7),(3.5,12)] if night else [(0,0),(2,7),(3.5,12)]):
   add(channels,start+k*beat,.43*pnote(r-12+nt,.56*beat,4),.5)
  for k in ([0,1,2,3] if night else [0,2]):add(channels,start+k*beat,.55*kick())
  for k in [1,3]:add(channels,start+k*beat,.18*brush(.25),.48)
  for k in np.arange(.5 if not night else .25,4,.5):
   add(channels,start+k*beat,.080*brush(.065),.71)
  if j in [0,3,6,9]:
   # Two soft pickup notes, echoed at the story's turn onto the dance floor.
   for q,nt in enumerate([7,11]):add(channels,start+(.25+.5*q)*beat,.20*pnote(r+24+nt,.58,3.8,1),.58)
 t=np.arange(N)/SR
 channels*=np.minimum(1,t/.22)[:,None]*np.minimum(1,np.clip((secs-t)/1.12,0,None))[:,None]
 channels/=max(np.sqrt(np.mean(channels*channels)),.001)
 channels*=.096
 with wave.open(str(D/(name+'-music.wav')),'wb') as f:
  f.setparams((2,2,SR,N,'NONE',''));f.writeframes((np.clip(channels,-.97,.97)*32767).astype('<i2').tobytes())
