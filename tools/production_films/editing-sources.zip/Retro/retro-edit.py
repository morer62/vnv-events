from pathlib import Path
import os,sys,subprocess,math,random,json,wave,functools,shutil,bisect
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
D=Path(__file__).parent
OUT=Path(os.environ['VNV_FILM_OUTPUT'])
STUDIO=Path(os.environ['VNV_FILM_LIBRARY']);VID=Path(os.environ['VNV_VIDEO_ASSETS']);BREAK=Path(os.environ['VNV_BREAK_RUSHES'])
W,H=1280,720;F=24;tinfo=json.loads((D.parent/'retro-glam-timings.json').read_text('utf-8'));T=tinfo[-1]['end']
cream=(251,239,215);gold=(237,196,130);rose=(242,115,155);teal=(105,211,205);ivory=(255,250,240);ink=(25,17,26)
@functools.lru_cache(None)
def ff(k,n):return ImageFont.truetype('C:/Windows/Fonts/'+{'serif':'BOD_R.TTF','italic':'BOD_I.TTF','bold':'Montserrat-Bold.ttf','sans':'Montserrat-Medium.ttf'}[k],n)
def tx(d,x,y,s,n=28,col=cream,k='sans',a=None):d.text((int(x),int(y)),s,font=ff(k,n),fill=col,anchor=a,stroke_width=0)
def track(d,x,y,s,n=17,col=gold,space=3):
 f=ff('bold',n)
 for c in s:
  d.text((int(x),int(y)),c,font=f,fill=col);x+=f.getlength(c)+space
def line(d,x1,y1,x2,y2,c=gold,w=1):d.line((round(x1),round(y1),round(x2),round(y2)),fill=c,width=w)
def rr(d,box,r,fill,out=None,w=1):d.rounded_rectangle(tuple(round(x) for x in box),radius=r,fill=fill,outline=out,width=w)
def star(d,x,y,r,c):
 d.polygon([(x,y-r),(x+r*.18,y-r*.18),(x+r,y),(x+r*.18,y+r*.18),(x,y+r),(x-r*.17,y+r*.16),(x-r,y),(x-r*.18,y-r*.18)],fill=c)
def clamp(x,a=0,b=1):return min(b,max(a,x))
def mix(a,b,t):return tuple(round(x*(1-t)+y*t) for x,y in zip(a,b))
def eas(x):x=clamp(x);return 1-(1-x)**3
def header(d,name,col=gold):
 track(d,65,41,'VNV ORIGINAL EXPERIENCES',14,col,2.7)
 if name:track(d,869,41,name,13,col,2.2)
def brief(d,x,y,label,h1,h2=None,accent=gold):
 track(d,x,y,label,16,accent,2.6);line(d,x,y+35,x+70,y+35,accent,2)
 tx(d,x-2,y+53,h1,73,ivory,'serif')
 if h2:tx(d,x-2,y+127,h2,72,accent,'italic')
@functools.lru_cache(None)
def base(tone):
 c0,c1,c2={'night':((25,16,29),(54,31,43),(119,70,51)),'gold':((27,17,22),(81,48,43),(145,98,55)),'neon':((24,16,39),(54,28,60),(28,80,87)),'wine':((38,18,32),(82,34,46),(142,71,45))}[tone]
 yy,xx=np.ogrid[:H,:W];a=np.clip((xx/W)*.67+(1-yy/H)*.25,0,1);ga=np.exp(-((xx-970)/500)**2-((yy-330)/360)**2)*.69
 arr=np.zeros((H,W,3),np.uint8)
 for i in range(3):arr[:,:,i]=np.clip((1-ga)*(c0[i]+(c1[i]-c0[i])*a)+ga*c2[i],0,255)
 return Image.fromarray(arr)
def filigree(d,t):
 for i in range(3):
  inset=34+i*5;w=54+i*11;c=mix((81,53,57),gold,.31+i*.1)
  for x,sx in [(inset,1),(W-inset,-1)]:
   for y,sy in [(inset,1),(H-inset,-1)]:
    d.line([(x+sx*w,y),(x,y),(x,y+sy*w)],fill=c,width=1)
 for j in range(17):
  x=(96+j*81+t*5.2)%1280;y=104+((j*147)%480);r=(.5+.5*math.sin(t*1.46+j*1.7))*.95
  if r>.39:d.ellipse((x-r,y-r,x+r,y+r),fill=mix((108,77,74),cream,.36*r))
def stamp(d,t,y=638):
 line(d,65,y,1213,y,(127,94,78));tx(d,65,y+11,'MIAMI  /  RETRO GLAM SESSIONS',13,(226,201,175),'bold')
 for i in range(40):
  h=2+14*abs(math.sin(i*.77+t*2.2)*math.cos(i*.57-.9*t));line(d,1060+i*3.8,y+19,1060+i*3.8,y+19-h,gold,2)
def discoball(d,cx,cy,r,t):
 # Mirrored tiles follow the latitude and longitude of a turning globe.
 def project(u,v):return (cx+r*math.cos(v)*math.sin(u),cy+r*math.sin(v))
 shift=(t*.26)%(math.pi/16)
 for j in range(15):
  v0=-math.pi/2+j*math.pi/15+.009;v1=-math.pi/2+(j+1)*math.pi/15-.009
  for i in range(-10,10):
   u0=i*math.pi/17+shift+.009;u1=(i+1)*math.pi/17+shift-.009
   if u1< -math.pi*.5 or u0>math.pi*.5:continue
   u0=max(u0,-math.pi*.5);u1=min(u1,math.pi*.5);u=(u0+u1)/2;v=(v0+v1)/2
   light=clamp(.12+.42*math.cos(u+.45)*math.cos(v+.06)+.22*math.cos(4.7*u+4.1*v-.42*t)+.14*math.cos(8.2*u-2.1*v+.52*t)+.18*math.cos(v+1.2))
   c=mix((54,37,49),(250,212,151),light);c=mix(c,(255,251,215),clamp((light-.8)*4))
   d.polygon((project(u0,v0),project(u1,v0),project(u1,v1),project(u0,v1)),fill=c)
 for j in range(4):
  u=-.57+.16*j+.13*math.sin(t*.56+j);v=-.4+.29*j;px,py=project(u,v);star(d,px,py,4+11*clamp(math.cos(1.6*t+j*1.9))**5,ivory)
def brasshalo(d,cx,cy,r,t):
 for j in range(3):d.arc((cx-r-j*12,cy-r-j*12,cx+r+j*12,cy+r+j*12),-127+3*t+j*4,75+5*t+j*3,fill=mix((78,55,55),gold,.38+j*.13),width=j%2+1)
def cassette(d,t):
 cx,cy=903,374;w,h=473,288;x=cx-w/2;y=cy-h/2;back=(28,18,39)
 for j in range(11):
  py=553+j*j*1.42;line(d,581,py,1220,py,mix((50,33,56),teal,.21),1)
 for j in range(-5,6):line(d,930,542,930+j*123,650,(77,74,90))
 rr(d,(x+7,y+12,x+w+8,y+h+13),17,(18,14,24));rr(d,(x,y,x+w,y+h),20,(60,42,69),mix(gold,rose,.5),3);rr(d,(x+13,y+13,x+w-13,y+h-11),11,back,(119,74,107),1)
 for j,co in enumerate((rose,(217,102,152),(164,117,176),teal)):d.polygon([(x+18,y+27+j*9),(x+266,y+27+j*9),(x+278,y+34+j*9),(x+18,y+34+j*9)],fill=co)
 tx(d,x+181,y+85,'SIDE  A',14,cream,'bold');rr(d,(x+39,y+116,x+w-39,y+210),33,(16,16,25),(180,151,129),2);rr(d,(cx-39,y+133,cx+39,y+193),3,(151,102,72),gold,1)
 for sign in [-1,1]:
  rx=cx+sign*128;ry=y+162;d.ellipse((rx-38,ry-38,rx+38,ry+38),fill=(195,173,144),outline=cream,width=2);d.ellipse((rx-26,ry-26,rx+26,ry+26),fill=(41,38,39))
  for j in range(7):
   a=t*1.55+j*math.tau/7;line(d,rx+13*math.cos(a),ry+13*math.sin(a),rx+24*math.cos(a),ry+24*math.sin(a),ivory,4)
  d.ellipse((rx-8,ry-8,rx+8,ry+8),fill=(125,113,109))
 d.polygon([(cx-125,y+h-13),(cx-100,y+h-56),(cx+100,y+h-56),(cx+125,y+h-13)],fill=(39,30,46),outline=(109,91,96))
 for ax in [x+28,x+w-28]:
  for ay in [y+27,y+h-29]:
   d.ellipse((ax-4,ay-4,ax+4,ay+4),fill=(140,125,128));line(d,ax-2,ay+2,ax+2,ay-2,back)
def camera_graph(d,t):
 cx,cy=905,370
 brasshalo(d,cx,cy,232,t)
 rr(d,(672,272,1141,521),20,(47,36,45),gold,3);rr(d,(680,284,1132,325),10,(146,119,101));rr(d,(698,316,1115,490),10,(44,32,40),(136,107,87));d.polygon([(745,277),(762,231),(876,231),(901,278)],fill=(106,81,72),outline=gold);rr(d,(1005,293,1079,314),2,(205,184,152))
 for j in range(18):line(d,701+j*4,357,701+j*4,471,(77,58,61))
 for j,(r,c) in enumerate([(103,(32,29,34)),(96,(88,76,77)),(86,(41,35,47)),(73,(89,94,100)),(64,(31,42,52)),(54,(46,67,76)),(42,(32,28,49))]):d.ellipse((cx-r,cy+42-r,cx+r,cy+42+r),fill=c,outline=mix(c,gold,.47),width=2)
 for j in range(6):
  a=t*.38+math.tau*j/6;aa=a+math.tau/6;rrr=25+6*math.sin(t*3);px=cx+rrr*math.cos(a);py=cy+42+rrr*math.sin(a)
  line(d,px,py,cx+52*math.cos(aa),cy+42+52*math.sin(aa),(112,103,128),2)
 for i in range(5):
  a=(t*.3+i*.23);star(d,1053+62*math.cos(a+i),298+42*math.sin(a+i*2),3+11*clamp(math.sin(t*2.9+i*1.3))**8,cream)
def console(d,t):
 x,y=655,282;rr(d,(x,y,x+545,y+256),14,(40,26,39),gold,2);track(d,x+19,y+17,'SHOW CONTROL',14,gold,2)
 for g,word in enumerate(['HOUSE','SOUND','LIGHT','STAGE']):
  xx=x+30+g*125;tx(d,xx,y+67,word,14,cream,'bold');line(d,xx+18,y+99,xx+18,y+189,(132,98,95),3)
  pos=122+25*math.sin(t*1.8+g);rr(d,(xx+4,y+pos-8,xx+32,y+pos+8),3,(216,185,149),cream)
  amp=4+math.floor((1+math.sin(t*4.6+g)) *2.5)
  for i in range(10):d.rectangle((xx+50,y+184-i*9,xx+68,y+189-i*9),fill=(teal if i<6 else gold) if i<amp else (71,52,59))
 for i,r in enumerate(['01','02','03','04']):tx(d,x+30+i*125,y+201,r,19,(187,150,129),'serif')
def dial(d,t):
 cx,cy=963,370
 brasshalo(d,cx,cy,192,t)
 for r,c in [(169,(38,27,35)),(156,(62,46,48)),(130,(26,25,34)),(91,(49,34,42))]:d.ellipse((cx-r,cy-r,cx+r,cy+r),fill=c,outline=mix(c,gold,.65),width=2)
 for i in range(72):
  a=i*math.tau/72;r=145-(i%3==0)*9;line(d,cx+r*math.cos(a),cy+r*math.sin(a),cx+151*math.cos(a),cy+151*math.sin(a),gold if i%3==0 else (112,91,92),2)
 labels=['70s','80s','90s','Y2K'];k=min(3,int(t/1.26));a=-.83*math.pi+eas((t%1.26)/.8)*.4+k*1.0;line(d,cx+102*math.cos(a),cy+102*math.sin(a),cx+145*math.cos(a),cy+145*math.sin(a),rose,5)
 tx(d,cx,cy-10,labels[k],54,gold,'serif','mm');track(d,cx-55,cy+28,'EDITION',12,cream,2.4)
def datafields(d,t):
 # Rows arrive on independent cues, keeping the program legible.
 for j,lab in enumerate(['Catering & décor','Multimedia','Staff & logistics']):
  xx=710;yy=252+j*83;p=eas((t-.2-j*.29)/.73);line(d,xx,yy+49,xx+round(415*p),yy+49,(174,126,105),2)
  if p>.12:
   x=xx+int(24*(1-p));tx(d,x,yy,lab,31,cream,'serif');tx(d,1089,yy+7,f'0{j+1}',15,gold,'bold')
@functools.lru_cache(None)
def veil(side):
 y,x=np.ogrid[:H,:W];ab=np.clip(.90*(1-x/W)**1.8+.12+.1*(y/H),.12,.96) if side=='left' else np.clip(.16+.81*(y/H)**2,.16,.97)+0*x
 a=np.zeros((H,W,4),np.uint8);a[:,:,:3]=[22,12,21];a[:,:,3]=np.clip(ab*255,0,255);return Image.fromarray(a,'RGBA')
def media(s):
 p,t,dt=s; playable=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(p)]))-t-.05; speed=min(1,playable/(dt+.40));cmd=['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-threads','2','-ss',str(t),'-t',str(dt+.15),'-i',str(p),'-an','-vf',f'setpts={1/speed:.8f}*PTS,fps={F},scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},format=rgb24','-f','rawvideo','-threads','2','pipe:1'];return subprocess.Popen(cmd,stdout=subprocess.PIPE,bufsize=W*H*3*2)

def wash(im,t,name):
 # Moving pools of theatrical light track the hardware and its active controls.
 frames={'neon':((93,28,85),(4,65,78)), 'portrait':((91,38,30),(56,27,64)), 'crew':((108,46,24),(26,70,66)), 'editions':((100,39,73),(83,58,31))}
 col1,col2=frames[name]
 yy,xx=np.mgrid[0:45,0:80]
 center=46+19*math.sin(1.83*t-.50)
 v1=np.exp(-((xx-center-(yy-22)*.47)/10)**2-((yy-17)/21)**2)
 v2=np.exp(-((xx-(114-center)+(yy-26)*.65)/8)**2-((yy-28)/18)**2)
 a=np.maximum(0,(xx-13)/33).clip(0,1)
 arr=np.zeros((45,80,3),np.uint8)
 for j in range(3):arr[:,:,j]=np.clip((v1*col1[j]+v2*col2[j])*a,0,245)
 gl=Image.fromarray(arr).resize((W,H),Image.Resampling.BILINEAR)
 return Image.fromarray(np.add(np.asarray(im).astype('int16'),np.asarray(gl),dtype='int16').clip(0,255).astype('uint8'))
def meter_back(d,t):
 for k in range(26):
  x=660+k*20
  lo=.5+.5*math.sin(t*4.3-k*.48)
  stop=200-lo*(35+32*(.5+.5*math.sin(k*.85+t*2.4)))
  line(d,x,213,x,stop,mix((100,49,90),teal, .25+lo*.51),6)
def animated_subject(im,fn,t,name):
 # A camera move across the subject is independent of the stage's moving lights.
 layer=Image.new('RGBA',(W,H));ld=ImageDraw.Draw(layer)
 if name=='neon':meter_back(ld,t)
 fn(ld,t)
 if name=='portrait':
  cx,cy=905,412; aperture=14+20*(.5+.5*math.cos(t*3.35))
  colors=[(130,113,134),(100,91,113),(137,119,136),(83,84,109),(121,105,124),(95,96,112)]
  for i,c in enumerate(colors):
   a=math.tau*i/6+t*.73;b=a+math.tau/6
   point=lambda ang,rad:(cx+rad*math.cos(ang),cy+rad*math.sin(ang))
   ld.polygon([point(a,49),point(b,49),point(b+.44,aperture),point(a+.44,aperture)],fill=c)
  ld.ellipse((cx-aperture,cy-aperture,cx+aperture,cy+aperture),fill=(22,28,39))
  # White reflections slide across the lens as the lens pulls focus.
  for k in range(2):
   angle=-127+23*math.sin(t*1.74)+k*144
   ld.arc((cx-74,cy-74,cx+74,cy+74),angle,angle+32,fill=gold,width=4)
 if name=='editions':
  cx,cy=963,370
  for idx,col in enumerate((rose,gold,teal)):
   a=(t*58+idx*120)%360
   ld.arc((cx-178,cy-178,cx+178,cy+178),a,a+58,fill=col,width=6)
   angle=math.radians(a+58);px=cx+178*math.cos(angle);py=cy+178*math.sin(angle)
   ld.ellipse((px-5,py-5,px+5,py+5),fill=ivory)
 if name=='neon':
  # Move the camera past a cassette on the riser as the tape spools.
  zoom=1.00+.032*t;angle=-4+1.8*t;center=(903,371);shx=-10+5*t;shy=6*math.cos(t*1.15)
 elif name=='portrait':
  zoom=.98+.040*t;angle=2.0*math.sin(t*.95);center=(905,392);shx=5.2*t;shy=7*math.cos(t*1.2)
 else:
  zoom=.99+.019*t;angle=1.2*math.sin(t*.86);center=(963,370);shx=-13+5.4*t;shy=5*math.cos(t*1.3)
 angle=math.radians(angle); a=math.cos(angle)/zoom;b=math.sin(angle)/zoom;cx,cy=center
 rendered=layer.transform((W,H),Image.Transform.AFFINE,(a,b,cx-a*(cx+shx)-b*(cy+shy),-b,a,cy+b*(cx+shx)-a*(cy+shy)),Image.Resampling.BILINEAR)
 im.paste(rendered,(0,0),rendered)
def run_cues(d,t):
 labels=['Catering & décor','Multimedia','Staff & logistics']
 for j,lab in enumerate(labels):
  x,y=682,206+j*112
  v=clamp((t-j*1.08)/1.02)
  bg=mix((62,40,49),(77,60,52),v)
  rr(d,(x,y,1194,y+90),8,bg,(137,101,90),1)
  tx(d,x+18,y+16,lab,29,ivory,'serif')
  tx(d,1114,y+20,('READY' if v>=1 else 'CUE '+str(j+1)),13,teal if v>=1 else gold,'bold')
  rr(d,(x+18,y+64,1166,y+71),3,(36,28,37))
  if v>0:
   ex=x+18+(1166-(x+18))*v
   rr(d,(x+18,y+64,ex,y+71),3,mix(rose,teal,v))
   star(d,ex,y+67,7+3*math.sin(t*4+j),ivory)
 # A moving transport head follows the dispatch timeline.
 x,y=686,564;extent=485
 line(d,x,y,x+extent,y,(150,113,98),2)
 for j in range(21):
  xx=x+j*extent/20;line(d,xx,y-4,xx,y+4,gold if j%5==0 else (117,80,82),2)
 pos=x+(t/3.96)*extent; d.polygon([(pos,y-10),(pos+6,y-17),(pos-6,y-17)],fill=teal)

def graphic(name,t):
 if name=='disco':
  im=base('gold').copy();d=ImageDraw.Draw(im);cx,cy=924,344;r=169+3*math.sin(t*.7)
  for j in range(13):
   a=-2.83+j*.20+.025*math.sin(t*.7);line(d,914+208*math.cos(a),368+208*math.sin(a),914+380*math.cos(a),368+380*math.sin(a),mix((69,44,49),gold,.12+j%3*.09),1)
  brasshalo(d,cx,cy,191,t);line(d,cx,42,cx,cy-r-5,gold,2);discoball(d,cx,cy,r,t);brief(d,73,232,'THE DISCO EDITION','Disco','in Gold.');tx(d,76,460,'Soul, funk and a gold-lit floor.',25,cream)
 elif name=='neon':
  im=wash(base('neon'),t,name);animated_subject(im,cassette,t,name);d=ImageDraw.Draw(im);brief(d,73,226,'THE EIGHTIES EDITION','Miami','Neon Nights.',rose);tx(d,77,461,'Freestyle and synth-pop.',25,cream)
 elif name=='portrait':
  im=wash(base('wine'),t,name);animated_subject(im,camera_graph,t,name);d=ImageDraw.Draw(im);brief(d,75,237,'THE PHOTO MOMENT','Ready for','your close-up?');tx(d,76,467,'A portrait in the light of your era.',24,cream)
 elif name=='desk':
  im=base('night').copy();d=ImageDraw.Draw(im);console(d,t);brief(d,75,232,'BEHIND THE SHOW','Every cue','has an owner.')
 elif name=='crew':
  im=wash(base('wine'),t,name);d=ImageDraw.Draw(im);run_cues(d,t);brief(d,75,225,'FROM LOAD-IN TO SHOWTIME','One crew.','One run of show.')
 elif name=='editions':
  im=wash(base('wine'),t,name);animated_subject(im,dial,t,name);d=ImageDraw.Draw(im);brief(d,73,219,'CHOOSE YOUR EDITION','One night.','One decade.');tx(d,76,458,'Disco · Neon · R&B & House · Y2K',24,cream)
 filigree(d,t);stamp(d,t);return im
S=[(0,'open',(BREAK/'playing.mp4',4.4)),(4.05,'decks',(BREAK/'playing.mp4',12.7)),(7.064,'disco',None),(12.60,'neon',None),(17.041,'band',(Path(os.environ['VNV_FILM_LIBRARY'])/'Service films v8'/'retro-stage-band.mp4',.08)),(20.85,'runway',(Path(os.environ['VNV_FILM_LIBRARY'])/'Service films v8'/'retro-stage-runway.mp4',.13)),(23.40,'portrait',None),(27.0,'desk',None),(30.3,'catering',(VID/'intro_vnv.mp4',19.23)),(32.30,'crew',None),(36.252,'event',(VID/'intro.mp4',1.1)),(39.00,'experience',(VID/'intro.mp4',10.48)),(43.105,'editions',None),(48.04,'close',(BREAK/'playing.mp4',.10))]
# Anchor each visual beat inside its original sentence, including the annual claim.
old_times=[0,7.064,17.041,25.767,36.252,43.105,52.175]
new_times=[i['start'] for i in tinfo]+[T]
def mapped(sec):
 i=max(0,min(5,bisect.bisect_right(old_times,sec)-1))
 return new_times[i]+(sec-old_times[i])/(old_times[i+1]-old_times[i])*(new_times[i+1]-new_times[i])
S=[(mapped(start),name,source) for start,name,source in S]
mark=Image.open(D/'retro-source-mark.png').convert('RGBA');mark.thumbnail((170,170),Image.Resampling.LANCZOS)
def livecards(im,name,t):
 original=im.copy() if name=='open' and t<1.04 else None
 if name in ('band','runway'):side='low'
 else:side='left'
 im.paste(veil(side),(0,0),veil(side));d=ImageDraw.Draw(im);header(d,'' if name in ['close','open'] else 'RETRO GLAM SESSIONS')
 if name=='open':brief(d,75,236,'RETRO GLAM SESSIONS','Time travel','starts here.');tx(d,77,466,'Choose the era you want to dance to.',25,cream)
 elif name=='decks':
  track(d,76,442,'THE DJ SET',17,gold,3.5);tx(d,73,478,'Drop the first track.',53,cream,'serif')
 elif name in ['band','runway']:
  track(d,72,532,'STAGE DESIGN STUDY',15,gold,2.5);tx(d,69,566,'The live set.' if name=='band' else 'The runway entrance.',51,ivory,'serif')
 elif name=='catering':brief(d,72,267,'PRODUCTION PARTNERS','Catering','on cue.')
 elif name=='event':brief(d,74,248,'VNV EVENT PRODUCTION','From small','to midsize.')
 elif name=='experience':
  track(d,74,251,'VNV PRODUCTION EXPERIENCE',16,gold,2.1);tx(d,71,281,'250+',126,ivory,'serif');tx(d,77,460,'small and midsize events per year',34,gold,'sans')
 elif name=='close':
  im.paste(mark,(82,147),mark);d=ImageDraw.Draw(im);tx(d,75,350,'Join the invitation list.',62,ivory,'serif');tx(d,78,449,'Ask about private or brand editions.',30,gold,'sans')
  line(d,79,521,430,521,gold,2);tx(d,78,542,'VNV EVENTS  /  RETRO GLAM',15,cream,'bold')
 filigree(d,t)
 if original is not None: return Image.blend(original,im,eas((t-.63)/.4))
 return im
def compose():
 from retro_score import compose as score
 score('retro-glam',T,105,46,6843)
def run():
 OUT.mkdir(exist_ok=True,parents=True);compose()
 voice=D.parent/'retro-glam-voice.wav';music=D/'retro-glam-music.wav';result=OUT/'retro-glam.mp4'
 filt='[1:a]loudnorm=I=-16:TP=-2.0:LRA=7,aresample=48000,aformat=channel_layouts=stereo[v];[2:a]loudnorm=I=-29.5:TP=-8:LRA=6,aresample=48000[m];[v][m]amix=inputs=2:normalize=0,alimiter=limit=0.90,afade=t=out:st='+str(T-.32)+':d=.32[a]'
 fout=subprocess.Popen(['ffmpeg','-y','-v','error','-threads','2','-f','rawvideo','-pix_fmt','rgb24','-s','1280x720','-r',str(F),'-i','pipe:0','-i',str(voice),'-i',str(music),'-filter_complex_threads','2','-filter_complex',filt.replace('d=.32','d=0.32'),'-map','0:v','-map','[a]','-vf','scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p','-c:v','libx264','-threads','3','-preset','veryfast','-crf','18','-maxrate','4M','-bufsize','7M','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-c:a','aac','-b:a','160k','-t',str(T),'-movflags','+faststart',str(result)],stdin=subprocess.PIPE)
 cuts=[round(x[0]*F) for x in S]+[round(T*F)];prev=None;last=None
 try:
  for idx,(start,name,source) in enumerate(S):
   fstart=cuts[idx];nframes=cuts[idx+1]-fstart;proc=media((source[0],source[1],nframes/F)) if source else None;print(name,nframes,flush=True);frozen=prev
   for j in range(nframes):
    t=j/F
    if proc:
     bb=proc.stdout.read(W*H*3)
     if len(bb)!=W*H*3:raise RuntimeError('Incomplete motion source '+name+' '+str(j))
     im=livecards(Image.frombytes('RGB',(W,H),bb),name,t)
    else:im=graphic(name,t)
    if j<4 and frozen and idx>0:
     im=Image.blend(frozen,im,eas((j+1)/5))
    if idx==0 and j<5:im=Image.blend(Image.new('RGB',(W,H),(21,13,22)),im,eas((j+1)/5))
    if idx==len(S)-1 and j>nframes-9:im=Image.blend(im,Image.new('RGB',(W,H),(19,12,19)),clamp((j-(nframes-9))/8))
    if j==min(nframes-1,20):im.save(D/('retro-study-'+name+'.jpg'),quality=85)
    fout.stdin.write(im.tobytes());prev=im
   if proc:proc.stdout.close();proc.terminate();proc.wait()
  fout.stdin.close();rc=fout.wait()
  if rc:raise RuntimeError(rc)
 except BaseException:
  if fout.poll() is None:fout.kill()
  raise
 shutil.copyfile(D.parent/'retro-glam-en.vtt',OUT/'retro-glam-en.vtt')
 subprocess.run(['ffmpeg','-y','-nostdin','-v','error','-ss','0.5','-i',str(result),'-frames:v','1','-quality','88',str(OUT/'retro-glam.webp')],check=True)
if __name__=='__main__':run()
