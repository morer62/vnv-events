from motion import *
# Each phase advances a piece of work, with artifacts traveling between roles.
@functools.lru_cache(None)
def card(top,title,detail,badge,hue):
 w,h=395,183;c=Image.new('RGBA',(w,h),(0,0,0,0));d=ImageDraw.Draw(c)
 rect(d,5,9,w-1,h-1,(6,24,28,145),rad=19)
 rect(d,1,1,w-8,h-10,hue,rad=18)
 txt(d,20,16,top,13,INK,'m');line(d,[(21,45),(w-29,45)],color(hue,INK,.28))
 txt(d,18,61,title,32,INK,'b');txt(d,20,105,detail,18,INK)
 txt(d,21,146,badge,12,INK,'m')
 return c
def put(im,surface,x,y,angle=0,scale=1):
 if scale!=1:surface=surface.resize((round(surface.width*scale),round(surface.height*scale)),Image.Resampling.BICUBIC)
 if angle:surface=surface.rotate(angle,Image.Resampling.BICUBIC,expand=True)
 im.paste(surface,(round(x-surface.width/2),round(y-surface.height/2)),surface)
def pointer(d,x,y):
 pts=[(x,y),(x+8,y+34),(x+13,y+23),(x+24,y+32),(x+29,y+27),(x+19,y+17),(x+30,y+13)]
 polygon(d,pts,WHITE,'#285250')
def stagger(i,phase):return ease((phase-.09*i)/.56)
data=[
 [('WELCOME DESK','Guest list A','First desk copy','Guest operations',MINT),('FLOOR MANAGER','Guest list B','Second desk copy','Compare the two copies',GOLD),('PRODUCTION','Shared list','Keep one source for arrival.','Both teams receive the update',BLUE)],
 [('PRODUCER','Program brief','The event team agrees on scope.','Brief approved',GOLD),('STAGE MANAGER','Opening cue','Assign the owner and timing.','Sent to stage',MINT),('WELCOME DESK','Ready for doors','The desk has the current plan.','Team notified',BLUE)],
 [('SHOW TIMING','5:30  Crew briefing','Producer confirms team roles.','Owner assigned',GOLD),('SHOW TIMING','6:00  Guest arrival','Welcome desk takes the floor.','Run of show updated',MINT),('SHOW TIMING','6:30  Sponsor intro','Stage manager cues the host.','Cue confirmed',BLUE)],
 [('VENDOR SELECTION','Compare the fit','Catering, decor and multimedia.','Availability checked',MINT),('PRODUCER REVIEW','Confirm the scope','Coordinate staffing and logistics.','Next handoff: producer',GOLD),('PRODUCTION TEAM','250+ events a year','Small and midsize events.','Plus our corporate productions',BLUE)],
 [('PRODUCER UPDATE','Doors moved','From 6:00 PM to 5:55 PM.','Publish schedule change',GOLD),('WELCOME DESK','Open at 5:55','The new time is on the desk.','Update received',MINT),('FLOOR TEAM','Crew notified','The right role gets the cue.','Schedule in sync',BLUE)],
 [('GUEST PAGE','Alex Rivera','Primary guest registered.','Two individual records',BLUE),('WELCOME DESK','Sam Rivera','Companion, arriving first.','Check in companion',GOLD),('SHARED GUEST LIST','Sam checked in','Alex remains expected.','Arrival shared with staff',MINT)],
 [('FOUNDATION','Volunteer shift','Assign a check-in volunteer.','Role: volunteer lead',MINT),('SPONSOR CONTACT','Sponsor package','Share approved deliverables.','Role: sponsor contact',GOLD),('ORGANIZATION','Donor record','Limit access to authorized staff.','Controlled by the organization',BLUE)],
 [('ROADMAP  /  PLANNED','Vendor onboarding','Collect contacts and arrival details.','Proposed workflow',GOLD),('ROADMAP  /  PLANNED','Agreements','Identify the next contract owner.','Proposed workflow',BLUE),('BY AGREEMENT','Branded app','Define the scope with the team.','Scoped separately',MINT)],
 [('WITH VNV PRODUCTION','Corporate team','Workspace setup and access.','Included in full production',MINT),('NONPROFIT SUPPORT','Nonprofit team','Workspace setup and access.','Included in approved engagements',GOLD),('FUTURE EVENTS','Use VNV-Q again','Carry your workflow forward.','vnvevents.com/event-production',MINT)]]
verbs=[('Compare','Review','Share'),('Brief','Assign','Dispatch'),('Brief','Open doors','Welcome'),('Compare','Review','Select'),('Publish','Receive','Confirm'),('Register','Check in','Confirm'),('Volunteer','Sponsor','Donor'),('Vendor','Contract','App scope'),('Corporate','Nonprofit','Next event')]
def packet(d,progress,xy,cc):
 x1,y1,x2,y2=xy;mid=(x1+x2)/2
 line(d,[(x1,y1),(mid,y1),(mid,y2),(x2,y2)],'#456763',3)
 p=ease(progress);xx=x1+(x2-x1)*p; yy=y1+(y2-y1)*p-14*math.sin(math.pi*p)
 rect(d,xx-22,yy-13,xx+22,yy+13,cc,rad=7);line(d,[(xx-10,yy-5),(xx,yy+3),(xx+10,yy-5)],INK,2)
def scanpass(canvas,d,elapsed,item):
 x=1004;y=273
 rect(d,x-3,y+8,x+117,y+172,'#0f292d',rad=12);rect(d,x,y,x+117,y+163,PAPER,rad=10)
 txt(d,x+12,y+13,'DEMO PASS',13,INK,'m')
 for a in range(8):
  for b in range(8):
   if ((a*31+b*17)^(a*b+item*5))%6<3:rect(d,x+19+a*10,y+41+b*10,x+27+a*10,y+49+b*10,INK)
 pulse=(math.sin(elapsed*5)+1)/2
 for xx,yy,sx,sy in [(x+13,y+36,1,1),(x+106,y+36,-1,1),(x+13,y+127,1,-1),(x+106,y+127,-1,-1)]:
  dd=3*pulse;line(d,[(xx+dd*sx+11*sx,yy+dd*sy),(xx+dd*sx,yy+dd*sy),(xx+dd*sx,yy+dd*sy+11*sy)],'#748f65',3)
 txt(d,x+13,y+139,'ARRIVAL',12,INK,'m')
def phone(canvas,d,t,k,phase):
 x,y=1006,238; rect(d,x-2,y+5,x+123,y+235,'#0a2326',rad=19);rect(d,x,y,x+122,y+228,'#dcebe3',rad=19);rect(d,x+7,y+7,x+115,y+220,'#193a3d',rad=14)
 rect(d,x+39,y+9,x+82,y+13,'#8eb6ad',rad=2)
 txt(d,x+16,y+30,'VNV-Q',13,MINT,'b');o=round(19*(1-ease(phase/.24)))
 rect(d,x+12,y+59+o,x+109,y+115+o,MINT,rad=7)
 txt(d,x+19,y+67+o,['UPDATE','DESK','FLOOR'][k],11,INK,'m');txt(d,x+18,y+88+o,'5:55 PM',17,INK,'b')
 for v in range(3):
  yy=y+139+v*19; line(d,[(x+39,yy),(x+90-9*v,yy)],'#72928f',2)
  if phase>(v+1)*.19:check(d,x+26,yy,4,MINT)
 rect(d,x+45,y+207,x+81,y+210,'#5c807a',rad=1)
def detail(idx,t,p,dimension):
 # Once the overview has been introduced, follow the item through the relevant roles.
 threshold=[.29,.34,.19,.20,.24,.25,.22,.13,.19][idx]
 if p<threshold:return None
 q=clamp((p-threshold)/(1-threshold));step=min(2,int(q*3));phase=min(1,q*3-step)
 im=Image.new('RGB',(706,409),'#19383d');d=ImageDraw.Draw(im)
 # Use local, bounded production diagrams. The moving paper is the object being assigned.
 for li in range(4):
  cir=70+li*42;d.arc((555-cir,174-cir,555+cir,174+cir),44,270,fill='#23464a',width=1)
 for i,k in enumerate(verbs[idx]):
  xx=21+i*214;txt(d,xx,16,k.upper(),15,MINT if i==step else GRAY,'m')
  rect(d,xx,45,xx+182,48,DARKLINE)
  if i<step:rect(d,xx,45,xx+182,48,MINT)
  elif i==step:rect(d,xx,45,xx+max(1,182*phase),48,GOLD,rad=1)
 # Secondary paper trailing the active card articulates the handoff (fast pickup, then transfer).
 base_x=234
 x=base_x-28+78*phase
 cy=190+8*math.sin(phase*math.pi)
 if step<2:
  back=card(*data[idx][step+1]);put(im,back,x-23,cy+13,angle=-4+phase,scale=.83)
 v=card(*data[idx][step]);put(im,v,x,cy,angle=3.4-6.5*phase,scale=.94+.035*math.sin(phase*math.pi))
 # Standalone demo view for the receiving team.
 if idx==5:
  sub=Image.new('RGB',(1280,720),'#19383d');sd=ImageDraw.Draw(sub);scanpass(sub,sd,t,step)
  patch=sub.crop((987,265,1140,452));im.paste(patch,(514,87))
 elif idx in (1,4,8):
  sub=Image.new('RGB',(1280,720),'#19383d');sd=ImageDraw.Draw(sub);phone(sub,sd,t,step,phase)
  im.paste(sub.crop((996,232,1137,480)),(518,79))
 else:
  x1,y1=445,197;x2,y2=589,149;packet(d,phase,(x1,y1,x2,y2),data[idx][step][-1])
  circ(d,605,146,35,'#2d5552',data[idx][step][-1],2);icon(d,605,146,['person','doc','flag'][(idx+step)%3],data[idx][step][-1])
  txt(d,604,202,['QUEUE','IN REVIEW','HANDOFF'][step],14,MINT,'m','mt')
 # Each role's status is written as the update arrives, then acknowledged.
 base=326;rect(d,18,base,687,395,'#23464a',rad=12)
 ico=data[idx][step][-1];circ(d,49,base+33,14,ico);check(d,49,base+32,6,INK)
 txt(d,77,base+13,'STATUS UPDATE',12,GRAY,'m')
 message=data[idx][step][3]
 txt(d,76,base+34,message[:max(1,math.ceil(len(message)*min(1,.16+phase*1.4)))],20,PAPER,'b')
 if phase>.38:
  tx=631-51*ease((phase-.38)/.48);ty=base+12+17*ease((phase-.38)/.58)
  pointer(d,tx,ty)
 return im
def push_overlay(im,idx,t,p,dur):
 threshold=[.29,.34,.19,.20,.24,.25,.22,.13,.19][idx]
 body=(491,169,1197,578)
 # A camera move establishes the entire workspace, then follows the active module.
 original=im.crop(body);sc=.82+.13*(1-math.cos(t*.68))*.5+.045*math.sin(t*.32)
 stage=Image.new('RGB',original.size,'#19383d')
 resized=original.resize((round(original.width*sc),round(original.height*sc)),Image.Resampling.BICUBIC)
 stage.paste(resized,(round((706-resized.width)*(.48+.24*math.sin(t*.52))),round((409-resized.height)*(.44+.20*math.cos(t*.49)))))
 im.paste(stage,body[:2])
 draw=detail(idx,t,p,dur)
 if draw is not None:
  loc=(p-threshold)*dur
  blend=ease(loc/.48)
  # Return to the animated floor overview when the narrative widens to the entire team.
  if idx==1:blend*=1-ease((p-.7)/.07)
  if idx==3:blend*=1-ease((p-.68)/.08)
  if idx==8:blend*=1-ease((p-.72)/.1)
  bg=im.crop((491,169,1197,578))
  if blend<1:
   dx=round(80*(1-blend));late=Image.new('RGB',draw.size,'#19383d')
   late.paste(draw,(dx,0));draw=Image.blend(bg,late,blend)
  im.paste(draw,(491,169))
 return im

