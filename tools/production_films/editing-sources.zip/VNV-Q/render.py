import os
from motion import *
from kinetic import push_overlay
import shutil
from PIL import ImageChops
HD=Path(os.environ['VNV_VIDEO_ASSETS'])
clipIndex=[
 (0,0.14,2.05,AS/'v5-corporate/corporate-events-preview.mp4',.15,'Welcome desk','ARRIVALS'),
 (3,.35,1.95,AS/'v5-activation/brand-activation-preview.mp4',.04,'Exhibitor build','VENDOR COORDINATION'),
 (4,1.7,4.16,HD/'intro.mp4',1.2,'Service team','LIVE PRODUCTION'),
 (6,1.0,2.45,AS/'v5-corporate/corporate-events-preview.mp4',5.65,'Community gathering','GUEST EXPERIENCE')]
size=(706,326)
def rawdecode(path,start,dur):
 b=subprocess.check_output(['ffmpeg','-v','error','-threads','2','-ss',str(start),'-i',str(path),'-t',str(dur+.12),'-an','-vf',f'fps={FPS},scale={size[0]}:{size[1]}:force_original_aspect_ratio=increase,crop={size[0]}:{size[1]}','-threads','1','-f','rawvideo','-pix_fmt','rgb24','-'])
 n=size[0]*size[1]*3
 return [Image.frombytes('RGB',size,b[z:z+n]) for z in range(0,len(b)-n+1,n)]
@functools.lru_cache(1)
def capture(idx):
 j,a,b,path,start,title,tagname=clipIndex[idx]
 return rawdecode(path,start,b-a)
def plates(idx,t,im):
 for n,(j,a,b,path,start,title,tagname) in enumerate(clipIndex):
  if j!=idx or not a<=t<=b:continue
  a1=ease((t-a)/.16)*ease((b-t)/.19)
  baseim=im.copy()
  d=ImageDraw.Draw(im)
  shell(d,j,'ON LOCATION',tagname)
  fr=capture(n);ii=min(len(fr)-1,max(0,int((t-a)*FPS)))
  im.paste(fr[ii],(490,177));rect(d,490,499,1196,569,'#18363b',rad=2)
  txt(d,512,519,title,25,PAPER,'b');txt(d,1170,529,'VNV EVENTS',14,MINT,'m','rt')
  if a1<.999:im=Image.blend(baseim,im,a1)
  break
 return im
def make_frame(i,t,p,start):
 im=base().copy();d=common(im,i,t,p,start)
 widgets=[clock,floor,lambda d,t,p:board(d,t,p,2),vendors,lambda d,t,p:board(d,t,p,4),roster,network,roadmap,passcard]
 widgets[i](d,t,p)
 duration=timings[i]['end']-timings[i]['start']
 im=push_overlay(im,i,t,p,duration);im=plates(i,t,im)
 return im
timings=json.loads((D.parent/'cuebook-timings.json').read_text('utf-8'));starts=[x['start'] for x in timings]
end=timings[-1]['end']+.45
def getframe(t):
 idx=min(len(starts)-1,max(0,bisect.bisect_right(starts,t)-1));dur=timings[idx]['end']-starts[idx];tl=t-starts[idx];p=clamp(tl/dur);im=make_frame(idx,tl,p,t)
 # A short, softened dissolve carries the viewer from one module to the next.
 if idx and tl<.32:
  prevdur=timings[idx-1]['end']-timings[idx-1]['start']
  prev=make_frame(idx-1,prevdur,1,t)
  w=ease(tl/.32);im=Image.blend(prev.filter(ImageFilter.GaussianBlur(1.7*w)),im,w)
 return im
def film(first=0,last=None,name='silent.mp4'):
 w=D/name
 proc=subprocess.Popen(['ffmpeg','-nostdin','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-threads','4','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(w)],stdin=subprocess.PIPE)
 stop=math.ceil(end*FPS) if last is None else last
 last=-1
 for k in range(first,stop):
  t=k/FPS;idx=min(8,bisect.bisect_right(starts,t)-1)
  if idx!=last:print(f'{idx+1}/9 at {t:.2f}',flush=True);last=idx
  im=getframe(t)
  if t<.14:im=Image.blend(Image.new('RGB',(W,H),DEEP),im,ease(t/.14))
  if end-t<.5:im=Image.blend(Image.new('RGB',(W,H),'#07191d'),im,ease((end-t)/.5))
  proc.stdin.write(im.tobytes())
 proc.stdin.close()
 if proc.wait():raise RuntimeError('Video encoding failed')
def previews():
 c=Image.new('RGB',(960,540))
 for j,b in enumerate(timings):
  rel=(b['end']-b['start'])*(.76 if j in [0,3] else .65)
  frame=getframe(b['start']+rel)
  c.paste(frame.resize((320,180)),((j%3)*320,(j//3)*180))
 c.save(D/'contact.png')
 # Poster identifies the platform, combining brand and the illustrated live floor.
 img=base().copy(); dr=ImageDraw.Draw(img);brand(dr)
 txt(dr,52,228,'VNV-Q',79,PAPER,'b')
 txt(dr,60,354,'Event Management Software',27,MINT);txt(dr,60,397,'by VNV Events',24,MINT)
 floor(dr,8,.8);img.save(OUT/'cuebook.webp',quality=91,method=5)
if __name__=='__main__':
 if '--preview' in sys.argv:previews()
 elif len(sys.argv)==4:film(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3])
 else:film()

