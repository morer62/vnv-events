from pathlib import Path
import subprocess,os,sys,shutil,json
import render
D=Path(__file__).parent
render.previews();render.film()
asset=render.OUT;t=render.end
master=D/'silent.mp4'
bed=Path(os.environ['VNV_FILM_LIBRARY'])/'Service films v8/Cuebook/score.wav'
graph=f'[1:a]loudnorm=I=-17:TP=-2:LRA=8,aresample=48000,aformat=channel_layouts=stereo,apad[v];[2:a]atrim=duration={t},loudnorm=I=-29:TP=-6:LRA=7,aresample=48000,afade=t=out:st={t-.85}:d=0.85[m];[v][m]amix=duration=longest:normalize=0,alimiter=limit=0.88:level=0,atrim=duration={t}[a]'
subprocess.run(['ffmpeg','-nostdin','-v','error','-y','-i',str(master),'-i',str(D.parent/'cuebook-voice.wav'),'-stream_loop','-1','-i',str(bed),'-filter_complex',graph,'-map','0:v','-map','[a]','-c:v','copy','-c:a','aac','-b:a','160k','-ar','48000','-movflags','+faststart','-metadata','title=VNV-Q | Event Management Software by VNV Events',str(asset/'cuebook.mp4')],check=True)
shutil.copyfile(D.parent/'cuebook-en.vtt',asset/'cuebook-en.vtt')
master.unlink()
print('VNV-Q master complete',round(t,3),flush=True)
