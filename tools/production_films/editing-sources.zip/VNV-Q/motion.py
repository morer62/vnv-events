import os
from pathlib import Path
import math,sys,json,subprocess,io,bisect,functools,itertools
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import numpy as np
D=Path(__file__).parent
OUT=Path(os.environ['VNV_FILM_OUTPUT'])
AS=OUT.parent
W,H,FPS=1280,720,24
INK='#122c31';DEEP='#0e262b';PAPER='#f8f8f3';MINT='#a9f1d6';GOLD='#e9bb79';GRAY='#b1c6c5';LINE='#416166';DARKLINE='#315054'
BLUE='#9bc5ef';DUSK='#ebbeab';WHITE='#ffffff';MONO='#d3e4dd'
titles=[('Five minutes','to doors.'),('One event.','One system.'),('Build the','run of show.'),('Pick the','right team.'),('Change a cue.','Tell the floor.'),('One guest.','One arrival.'),('Keep the','cause moving.'),('Plan the','next tools.'),('Explore our','production services.')]
roles=['At the welcome desk','An event workspace','The production brief','Vendor selection','Live coordination','Guest operations','Year-round tools','Product roadmap','VNV-Q event software']
notes=[['Two lists. Which one','runs the room?'],['The producer, welcome desk','and floor team share a plan.'],['Every cue gets a time,','a place and an owner.'],['Compare the scope and','confirm who will deliver.'],['The right update reaches','the people doing the work.'],['A companion can arrive','before the principal.'],['Give supporters a way to','stay involved after the event.'],['Decide what belongs in','your next production.'],['Platform setup and access','are included for eligible teams.']]
@functools.lru_cache(None)
def font(sz,style='n'):
 name={'n':'segoeui.ttf','b':'segoeuib.ttf','l':'segoeuil.ttf','m':'consola.ttf','s':'georgia.ttf','i':'georgiai.ttf'}[style]
 return ImageFont.truetype('C:/Windows/Fonts/'+name,sz)
def txt(d,x,y,s,sz,c=WHITE,f='n',anchor='lt'):
 d.text((round(x),round(y)),s,font=font(sz,f),fill=c,anchor=anchor,stroke_width=0)
def rect(d,x0,y0,x1,y1,fill,outline=None,rad=0,width=1):
 b=(round(x0),round(y0),round(x1),round(y1))
 if rad:d.rounded_rectangle(b,radius=rad,fill=fill,outline=outline,width=width)
 else:d.rectangle(b,fill=fill,outline=outline,width=width)
def line(d,pts,c,w=2):d.line([(round(x),round(y)) for x,y in pts],fill=c,width=w,joint='curve')
def circ(d,x,y,r,c,edge=None,w=1):d.ellipse((round(x-r),round(y-r),round(x+r),round(y+r)),fill=c,outline=edge,width=w)
def clamp(v):return min(1,max(0,v))
def ease(v):v=clamp(v);return v*v*(3-2*v)
def interp(a,b,t):return a+(b-a)*t
def color(a,b,p):
 p=clamp(p);a=bytes.fromhex(a.lstrip('#'));b=bytes.fromhex(b.lstrip('#'))
 return tuple(round(aa+(bb-aa)*p) for aa,bb in zip(a,b))
def check(d,x,y,r,c):line(d,[(x-r,y),(x-r*.25,y+r*.6),(x+r,y-r*.8)],c,max(2,round(r*.35)))
def tag(d,x,y,s,fg=MINT,bg='#24433f',size=15):
 f=font(size,'b');ww=f.getlength(s)+26;rect(d,x,y,x+ww,y+size+15,bg,rad=12);txt(d,x+13,y+6,s,size,fg,'b');return ww
def arrow(d,x,y):line(d,[(x-9,y-1),(x+7,y-1),(x+2,y-7)],MINT,2);line(d,[(x+7,y-1),(x+2,y+4)],MINT,2)
def icon(d,x,y,n,col=MINT):
 if n=='person':circ(d,x,y-6,5,None,col,2);d.arc((x-10,y,x+10,y+19),180,360,fill=col,width=2)
 elif n=='doc':
  rect(d,x-8,y-11,x+8,y+11,None,col,rad=2,width=2);line(d,[(x-4,y-4),(x+4,y-4)],col,2);line(d,[(x-4,y+1),(x+4,y+1)],col,2)
 elif n=='flag':
  line(d,[(x-7,y+10),(x-7,y-10),(x+8,y-9),(x+4,y-2),(x-7,y-2)],col,2)
 elif n=='clock':
  circ(d,x,y,10,None,col,2);line(d,[(x,y-7),(x,y),(x+5,y+3)],col,2)
 else:
  rect(d,x-9,y-8,x+9,y+8,None,col,rad=2,width=2);line(d,[(x-8,y-2),(x+8,y-2)],col,2)
@functools.lru_cache(None)
def base():
 yy,xx=np.meshgrid(np.linspace(0,1,H),np.linspace(0,1,W),indexing='ij')
 v=np.clip(.48+(.48*xx)+.18*np.cos(yy*2.6+(1-xx)*2.3),0,1)
 a=np.array([8,26,30]);b=np.array([32,66,65]);im=Image.fromarray((a+(b-a)*v[:,:,None]).astype(np.uint8))
 return im
def brand(d): 
 x,y=57,42
 for dx,dy,col in [(4,-6,MINT),(0,2,PAPER)]:
  line(d,[(x+dx,y+dy),(x+25+dx,y+dy-7),(x+39+dx,y+dy),(x+14+dx,y+dy+7),(x+dx,y+dy)],col,2)
 txt(d,112,32,'VNV-Q',24,PAPER,'b');line(d,[(228,34),(228,55)],LINE);txt(d,245,38,'EVENT MANAGEMENT SOFTWARE',16,MINT,'m')
def common(im,idx,t,p,T):
 d=ImageDraw.Draw(im);brand(d)
 txt(d,1221,40,'PRODUCTION FIELD GUIDE',15,GRAY,'m','rt')
 line(d,[(56,76),(1223,76)],DARKLINE,1);y=129
 tag(d,57,y,roles[idx],fg=MINT,bg='#244541',size=16)
 shift=(1-ease(t/.45))*18
 for j,c in enumerate(titles[idx]):
  fs=60 if len(c)<13 else 52
  while font(fs,'b').getlength(c)>385: fs-=1
  txt(d,54+shift,210+j*68,c,fs,PAPER if j==0 else MINT,'b')
 for j,c in enumerate(notes[idx]):txt(d,58,390+j*32,c,23,'#dce5df','n')
 line(d,[(58,479),(108,479)],GOLD,3)
 if idx==8:
  txt(d,59,508,'vnvevents.com/event-production',23,PAPER,'n')
 else:
  txt(d,58,506,'VNV-Q   /   '+str(idx+1).zfill(2),15,GRAY,'m')
 if idx==2:
  labels=['Discover','Design the Scope','Build the System','Produce the Event','Close & Recap']
  x=57
  for num,label in enumerate(labels):
   width=font(16,'b').getlength(label)+32
   active=min(4,int(p*5))==num
   rect(d,x,616,x+width,643,'#396357' if active else '#1b3638',GOLD if active else DARKLINE,rad=5)
   txt(d,x+width/2,622,label,15,PAPER if active else GRAY,'b','mt');x+=width+9
 for k in range(9):
  x=57+k*130
  progress=1 if k<idx else (p if k==idx else 0)
  rect(d,x,652,x+121,655,DARKLINE)
  if progress>0:rect(d,x,652,x+max(1,121*progress),655,MINT if idx==k else '#6e9890')
 txt(d,58,670,'VNV EVENTS',13,GRAY,'m')
 txt(d,1221,670,'ILLUSTRATIVE EVENT WORKFLOW',13,GRAY,'m','rt')
 return d
def shell(d,k,title,sub):
 rect(d,469,116,1224,608,'#0b2226',rad=25);rect(d,465,109,1220,600,'#19383d',LINE,rad=25)
 for j in range(3):circ(d,493+j*13,136,3,['#61817c',GOLD,MINT][j])
 txt(d,562,130,title,15,MINT,'m');txt(d,1192,130,sub,14,GRAY,'m','rt')
 line(d,[(486,161),(1196,161)],DARKLINE)
_angle=.72
def iso(x,y,z=0):
 cs=math.cos(_angle);sn=math.sin(_angle)
 return (855+61*(cs*x-sn*y),418+26*(sn*x+cs*y)-z)
def polygon(d,pts,c,edge=None):d.polygon([(round(x),round(y)) for x,y in pts],fill=c,outline=edge)
def slab(d,x,y,w,h,tall,c,c1=None):
 z=tall;a=iso(x,y);b=iso(x+w,y);c0=iso(x+w,y+h);e=iso(x,y+h)
 top=[(p[0],p[1]-z) for p in [a,b,c0,e]]
 polygon(d,[e,c0,top[2],top[3]],color(c,'#04181e',.3));polygon(d,[b,c0,top[2],top[1]],color(c,'#04181e',.55));polygon(d,top,c,c1)
def arrowroute(d,path,p,c):
 for aa,bb in zip(path,path[1:]):line(d,[aa,bb],color(c,'#122c31',.5),3)
 weights=[math.dist(a,b) for a,b in zip(path,path[1:])];travel=(p%1)*sum(weights)
 for j,w in enumerate(weights):
  a,b=path[j:j+2]
  if travel<=w:
   f=travel/w if w else 0;xx=interp(a[0],b[0],f);yy=interp(a[1],b[1],f);circ(d,xx,yy,7,c);circ(d,xx,yy,3,INK);return
  travel-=w
def floor(d,t,p):
 global _angle
 _angle=.52+.52*(1-math.cos(.48*t))/2
 shell(d,0,'VENUE FLOOR','CUE ROUTING')
 outline=[iso(-3,-3),iso(3,-3),iso(3,3),iso(-3,3)]
 polygon(d,outline,'#224a4b','#5b8581')
 for j in range(-3,4):
  line(d,[iso(-3,j),iso(3,j)],'#406364',1);line(d,[iso(j,-3),iso(j,3)],'#406364',1)
 f=ease(t/.7);slab(d,-2.8,-2.7,3,.7,28*f,'#bea577');slab(d,1.7,-1.6,.75,3.6,22*f,'#416d70')
 for x in [-1.8,-.8,.2]:
  for y in [-.3,.8,1.9]:slab(d,x,y,.38,.35,10*f,'#70a9a1')
 pts=[iso(-2.9,2.6,3),iso(.8,2.6,3),iso(.8,-1.4,3),iso(-.7,-1.4,3)]
 arrowroute(d,pts,t/4,MINT);arrowroute(d,pts,t/4+.42,GOLD)
 tag(d,503,181,'LIVE FLOOR',MINT,'#294c49');txt(d,1180,512,'STAGE  /  MAIN ROOM',15,GRAY,'m','rt')
 line(d,[(634,491),(666,475),(687,475)],GOLD);txt(d,502,501,'Guest entrance',18,PAPER,'n')
def clock(d,t,p):
 shell(d,0,'ARRIVALS','BEFORE DOORS')
 x,y=833,357
 for rr,c in [(153,'#294a4d'),(135,'#456b67'),(117,'#294a4d')]:circ(d,x,y,rr,None,c,2)
 for k in range(60):
  a=-math.pi/2+k*math.pi/30;r=130 if k%5 else 121
  line(d,[(x+r*math.cos(a),y+r*math.sin(a)),(x+135*math.cos(a),y+135*math.sin(a))],MINT if k%5==0 else LINE,3 if k%5==0 else 1)
 a=-math.pi/2+(t*.55)%(2*math.pi);d.arc((x-152,y-152,x+152,y+152),-90,-90+max(5,310*ease(t/3)),fill=GOLD,width=5);circ(d,x+135*math.cos(a),y+135*math.sin(a),5,GOLD)
 txt(d,x,y-21,'5:55',58,PAPER,'b','mt');txt(d,x,y+47,'PM',17,MINT,'m','mt')
 tag(d,503,181,'WELCOME DESK',MINT,'#294c49')
 txt(d,1183,540,'DOORS OPEN AT 6:00 PM',16,GOLD,'m','rt')
def board(d,t,p,idx):
 shell(d,idx,'RUN OF SHOW','SHARED SCHEDULE')
 arr=[('5:30 PM','Crew briefing','Producer'),('6:00 PM','Open doors','Welcome desk'),('6:30 PM','Sponsor welcome','Stage manager')]
 active=min(2,int(p*3));match=(idx==4);change=ease((p-.28)/.14)
 for i,(tm,title,role) in enumerate(arr):
  yy=209+i*97;shift=round((1-ease((t-i*.10)/.45))*31)
  sel= i==(1 if match else active);x=500+shift
  rect(d,x,yy,1184,yy+78,'#284b4d' if sel else '#203d41','#609184' if sel else DARKLINE,rad=13)
  rect(d,x,yy+12,x+3,yy+66,GOLD if sel else LINE,rad=1)
  txt(d,x+20,yy+25,'5:55 PM' if match and i==1 and change>.5 else tm,20,MINT,'m')
  txt(d,x+156,yy+23,title,25,PAPER,'b');txt(d,1164,yy+29,role,17,GRAY,'n','rt')
  if sel: circ(d,x+133,yy+38,3+2*math.sin(t*3),GOLD)
 prog=int(ease((p-.2)/.5)*3)
 for i,n in enumerate(['Producer','Welcome desk','Floor team']):
  x=510+i*227; circ(d,x,542,7,MINT if prog>i else LINE);txt(d,x+14,535,n,17,PAPER if prog>i else GRAY)
def vendors(d,t,p):
 shell(d,3,'VENDOR SELECTION','PRODUCER WORKFLOW')
 if p<.58:
  rows=[('Catering & decor','Guest experience and service scope',MINT),('Multimedia','Sound, screens and show cues',GOLD),('Staffing & logistics','Crew availability, routes and timing',BLUE)]
  for i,(name,det,c) in enumerate(rows):
   y=200+i*107; rect(d,501,y,1181,y+87,'#234247',LINE,rad=13);circ(d,544,y+43,20,'#304f51');icon(d,544,y+43,['clock','person','doc'][i],c)
   txt(d,583,y+12,name,24,PAPER,'b');txt(d,584,y+47,det,18,GRAY)
   if ease((p-i*.11)/.15)>.5:check(d,1140,y+43,8,c)
 else:
  k=ease((p-.58)/.22);txt(d,511,209,'VNV EVENT EXPERIENCE',17,GOLD,'m')
  txt(d,503,257,str(round(k*250))+('+' if k>.999 else ''),103,MINT,'b');txt(d,514,380,'small and midsize events each year',31,PAPER,'b')
  line(d,[(513,447),(513+k*565,447)],MINT,3);txt(d,514,479,'Alongside corporate production',21,GRAY)
def roster(d,t,p):
 shell(d,5,'GUEST LIST','INDIVIDUAL CHECK-IN')
 tag(d,503,183,'DEMO GUESTS',MINT,'#294c49')
 for i,(n,rel) in enumerate([('Alex Rivera','Primary guest'),('Sam Rivera','Companion of Alex Rivera')]):
  y=248+i*112;rect(d,498,y,1189,y+94,'#244148',LINE,rad=14)
  circ(d,543,y+46,22,'#365659');icon(d,543,y+44,'person',GOLD if i==0 else MINT)
  txt(d,584,y+15,n,27,PAPER,'b');txt(d,585,y+51,rel,17,GRAY)
  arrived=(p>.35 if i==1 else p>.83)
  if arrived:tag(d,1045,y+33,'Checked in',MINT,'#2a5b50',14)
  else:txt(d,1146,y+40,'Expected',17,GRAY,'n','rt')
 progress=0 if p<.35 else (1 if p<.83 else 2)
 txt(d,508,506,f'{progress} of 2 arrived',24,PAPER,'b');line(d,[(505,551),(1167,551)],LINE,3)
 if progress:line(d,[(505,551),(505+331*progress,551)],MINT,4)
def network(d,t,p):
 shell(d,6,'FOUNDATION WORKSPACE','AUTHORIZED ROLES')
 x,y=839,357
 for i,(dx,dy,n,c) in enumerate([(-206,-96,'Donations',MINT),(198,-96,'Volunteers',GOLD),(0,146,'Sponsors',BLUE)]):
  xx,yy=x+dx,y+dy;route=[(x,y),((x+xx)/2,y),(xx,yy)]
  arrowroute(d,route,t/3+i*.37,c);circ(d,xx,yy,33,'#254346',c,2);icon(d,xx,yy,['doc','person','flag'][i],c)
  txt(d,xx,yy+44,n,21,PAPER,'b','mt')
 circ(d,x,y,63,'#214b49',MINT,3);rect(d,x-15,y-5,x+15,y+20,None,MINT,4,3);d.arc((x-11,y-22,x+11,y),180,360,fill=MINT,width=3);circ(d,x,y+6,3,GOLD)
def roadmap(d,t,p):
 shell(d,7,'PRODUCT ROADMAP','SCOPE REVIEW')
 cards=[('Vendor onboarding','PLANNED','Submit contacts and arrival details.','doc'),('Contract management','PLANNED','Track agreements and next actions.','flag'),('Branded mobile app','BY AGREEMENT','Confirm build, access and support.','person')]
 for i,(item,status,detail,ic) in enumerate(cards):
  y=199+116*i;active=min(2,int(p*3))==i
  rect(d,499,y,1184,y+98,'#26484c' if active else '#203c41',GOLD if active else LINE,rad=13);icon(d,536,y+42,ic,MINT);txt(d,572,y+17,item,25,PAPER,'b');txt(d,573,y+57,detail,18,GRAY);tag(d,1042,y+18,status,GOLD,'#3b4740',12)
def passcard(d,t,p):
 shell(d,8,'PARTNER ACCESS','VNV-Q')
 rect(d,527,197,1156,520,'#0f292c',rad=20);rect(d,519,187,1147,507,'#a9f1d6',rad=20)
 txt(d,550,213,'EVENT SOFTWARE',18,INK,'m');txt(d,1113,213,'EVENT WORKSPACE',16,INK,'m','rt')
 txt(d,547,260,'Included.',62,INK,'b');line(d,[(550,356),(1111,356)],'#71aa98',2)
 txt(d,552,384,'Platform setup + continued access',23,INK,'b')
 # The access seal closes, then cycles gently around the verified workspace.
 cx,cy=1065,294
 circ(d,cx,cy,42,None,'#73b8a0',2)
 d.arc((cx-38,cy-38,cx+38,cy+38),-90+(t*18)%360,105+(t*18)%360,fill='#32685c',width=3)
 v=ease(t/2.4)
 if v>0:
  mid=(cx-3,cy+9)
  line(d,[(cx-15,cy),(interp(cx-15,mid[0],min(1,v*2)),interp(cy,mid[1],min(1,v*2)))],INK,4)
  if v>.5:line(d,[mid,(interp(mid[0],cx+19,2*v-1),interp(mid[1],cy-12,2*v-1))],INK,4)
 for i in range(45):
  xx=553+i*4;hh=round(29+3*math.sin(i*7.2));ww=1+(i*7%3);rect(d,xx,442,xx+ww,442+hh,INK)
 txt(d,1110,445,'CORPORATE  /  NONPROFIT',16,INK,'m','rt')
 txt(d,832,550,'Explore our production services.',22,PAPER,'s','mt')

