import os
from pathlib import Path
import sys,re,ast,json,hashlib,html,bisect,difflib,functools,shutil
D=Path(__file__).parent
out=Path(os.environ['VNV_FILM_OUTPUT'])
source=ast.parse((D.parent/'vnv-hub-qa-20261126/produce-neural-narration.py').read_text(encoding='utf-8-sig'))
exec(compile(ast.Module(body=[f for f in source.body if isinstance(f,ast.FunctionDef) and f.name in ('norm','syllable_align','timestamp')],type_ignores=[]),'alignment','exec'))
weak=set('the a an to of with or and your their our its for at on in from that as who can will should is are was has have these those this before after'.split())
good=set('and so then when before after because with until while if which how from through'.split())
def breakscore(left,right):
 last=left.strip(',.?!:;”"').lower();nxt=right.strip(',.?!:;“"').lower()
 return (19 if last in weak else 0) - (8 if left.endswith((',',';',':')) else 0)-(7 if nxt in good else 0)
def lines(arr):
 words=[w[0] for w in arr];text=' '.join(words)
 if len(text)<=42:return (0,text)
 opts=[]
 for i in range(1,len(words)):
  a=' '.join(words[:i]);b=' '.join(words[i:])
  if max(len(a),len(b))>42: continue
  val=.17*abs(len(a)-len(b))+breakscore(words[i-1],words[i])+(12 if min(len(a),len(b))<11 else 0)
  opts.append((val,a+'\n'+b))
 return min(opts) if opts else (1e6,None)
def group(words):
 @functools.lru_cache(None)
 def go(i):
  if i==len(words):return (0,[])
  best=(1e9,[])
  for j in range(i+1,len(words)+1):
   span=words[i:j];dur=span[-1][2]-span[0][1]
   lc,msg=lines(span)
   if msg is None or dur>6.7:break
   hidden=sum(x[0].endswith(('.', '?','!')) for x in span[:-1])
   cost=9+lc*.3+26*hidden+(3.7-dur)**2*1.2+8*max(0,1.4-dur)+35*(len(span)==1)
   if j<len(words):
    gap=words[j][1]-words[j-1][2]
    cost+=breakscore(words[j-1][0],words[j][0])*.8-min(gap,.6)*12
    if words[j-1][0].endswith(('.', '?','!')):cost-=19
   child,seq=go(j);total=cost+child
   if total<best[0]:best=(total,[(span[0][1],span[-1][2],msg)]+seq)
  return best
 total,groups=go(0)
 assert groups
 return groups
for script in sorted(D.glob('*-script.json')):
 slug=script.name.removesuffix('-script.json');timings=json.loads((D/f'{slug}-timings.json').read_text(encoding='utf-8'))
 cues=[]
 for scene in timings:
  t=scene['text'];spoken=re.sub(r'\bVNV\b','V N V',t).replace('Cuebook','Cue Book')
  key=hashlib.sha256(('en-US-AndrewNeural-9%'+spoken).encode()).hexdigest()[:18]
  bound=[json.loads(l) for l in (D/'spoken-cache'/f'{key}.jsonl').read_text(encoding='utf-8').splitlines() if l.strip()]
  w=syllable_align(t,bound)
  start=int(max(0,(w[0][1]-.07))*24000)/24000
  for a,b,msg in group(w):cues.append((scene['start']+a-start,min(scene['end'],scene['start']+b-start),msg))
 words=' '.join(c['text'] for c in timings).split()
 assert words==' '.join(c[2] for c in cues).split()
 assert all(max(len(l) for l in c[2].splitlines())<=42 and len(c[2].splitlines())<=2 for c in cues)
 assert all(b>a and (i==0 or a>=cues[i-1][1]-.0004) for i,(a,b,t) in enumerate(cues))
 body='WEBVTT\n\n'+'\n\n'.join(f'{timestamp(a)} --> {timestamp(b)}\n{msg}' for a,b,msg in cues)+'\n'
 target=D/f'{slug}-en.vtt';tmp=target.with_suffix('.draft');tmp.write_text(body,encoding='utf-8',newline='\n');tmp.replace(target)
 dest=out/target.name
 if dest.exists() or (out/f'{slug}.mp4').exists():shutil.copyfile(target,dest)
 print(slug,len(cues),'minimum seconds',round(min(b-a for a,b,_ in cues),2),'orphans',[m for _,_,m in cues if len(m.split())<2])

