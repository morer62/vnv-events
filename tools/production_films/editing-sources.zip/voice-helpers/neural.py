import asyncio, bisect, difflib, hashlib, html, io, json, re, subprocess, sys, wave
from pathlib import Path
import edge_tts
src=Path(sys.argv[1]); target=Path(sys.argv[2]); voice=sys.argv[3] if len(sys.argv)>3 else 'en-US-AndrewNeural'; rate=sys.argv[4] if len(sys.argv)>4 else '+0%'
scenes=json.loads(src.read_text(encoding='utf-8-sig')); scenes=[{'id':v.get('id',str(n)),'text':v['text']} if isinstance(v,dict) else {'id':str(n),'text':v} for n,v in enumerate(scenes)]
cache=src.parent/'spoken-cache'; cache.mkdir(exist_ok=True)
def norm(s):return re.sub('[^a-z0-9]','',html.unescape(s).lower())
def timestamp(t):
 m=int(round(t*1000));return f'{m//3600000:02d}:{m//60000%60:02d}:{m//1000%60:02d}.{m%1000:03d}'
async def make(n,v,limit):
 spoken=re.sub(r'\bVNV\b','V N V',v['text']).replace('Cuebook','Cue Book')
 stem=cache/hashlib.sha256((voice+rate+spoken).encode()).hexdigest()[:18]; mp3=stem.with_suffix('.mp3'); meta=stem.with_suffix('.jsonl')
 async with limit:
  if not (mp3.exists() and mp3.stat().st_size>1500 and meta.exists() and meta.stat().st_size>60):
   for t in range(5):
    try:
     await edge_tts.Communicate(spoken,voice,rate=rate,boundary='WordBoundary',connect_timeout=15,receive_timeout=50).save(str(mp3),str(meta))
     if mp3.stat().st_size<1500 or meta.stat().st_size<60: raise ValueError('empty audio/metadata')
     break
    except Exception:
     if t==4:raise
     await asyncio.sleep(1.3*(t+1))
 return (mp3,[json.loads(l) for l in meta.read_text(encoding='utf-8').splitlines() if l.strip()])
def syllable_align(text,words):
 tokens=text.split(); meta=''.join(norm(w['text']) for w in words); orig=''.join(norm(t) for t in tokens);positions={};match=difflib.SequenceMatcher(None,orig,meta,autojunk=False)
 if match.ratio()<.85:raise ValueError(f'Alignment mismatch: {orig} -> {meta}')
 for a,b,n in match.get_matching_blocks():
  for k in range(n):positions[a+k]=b+k
 source_ends=[];cur=0
 for w in words:cur+=len(norm(w['text']));source_ends.append(cur)
 out=[];i=0
 for t in tokens:
  end=i+len(norm(t)); loc=[positions[j] for j in range(i,end) if j in positions]
  if not loc:raise ValueError('No timestamp for '+t)
  first=words[bisect.bisect_right(source_ends,loc[0])];last=words[bisect.bisect_right(source_ends,loc[-1])]
  out.append((t,first['offset']/1e7,(last['offset']+last['duration'])/1e7));i=end
 return out
def groups(tokens):
 result=[];line=[]
 for t in tokens:
  msg=' '.join([v[0] for v in line]+[t[0]])
  if line and (len(msg)>55 or t[2]-line[0][1]>3.4):result.append(line);line=[]
  line.append(t)
  if re.search(r'[.?!][”"]?$',t[0]) or (len(line)>=5 and t[0].endswith((',',':',';'))):result.append(line);line=[]
 if line:result.append(line)
 return result
async def main():
 limit=asyncio.Semaphore(2);parts=await asyncio.gather(*(make(i,v,limit) for i,v in enumerate(scenes)));timeline=[];cues=[];offset=0;hz=24000
 with wave.open(str(target.with_name(target.name+'-voice.wav')),'wb') as wav:
  wav.setparams((1,2,hz,0,'NONE','not compressed'))
  for n,((mp3,words),scene) in enumerate(zip(parts,scenes)):
   tokens=syllable_align(scene['text'],words);raw=subprocess.check_output(['ffmpeg','-hide_banner','-loglevel','error','-i',str(mp3),'-f','s16le','-ac','1','-ar',str(hz),'pipe:1']);start=max(0,int((tokens[0][1]-.07)*hz));end=min(len(raw)//2,int((tokens[-1][2]+(.19 if n+1<len(scenes) else .3))*hz))
   if end<start:raise ValueError('negative duration')
   wav.writeframes(raw[2*start:2*end]);base=offset/hz; abs_end=(offset+end-start)/hz
   for phrase in groups(tokens):
    s=max(base,base+phrase[0][1]-start/hz);e=min(abs_end,base+phrase[-1][2]-start/hz);msg=' '.join(v[0] for v in phrase);cues.append([s,max(s+.05,e),msg])
   timeline.append(dict(id=scene['id'],start=round(base,3),end=round(abs_end,3),text=scene['text']));offset+=end-start
 for i in range(len(cues)-1):
  s,e,t=cues[i];cues[i][1]=min(cues[i+1][0]-.004,max(e,s+.38))
  if cues[i][1]<=s:raise ValueError('overlap')
 target.with_name(target.name+'-timings.json').write_text(json.dumps(timeline,indent=2,ensure_ascii=False),encoding='utf-8')
 target.with_name(target.name+'-en.vtt').write_text('WEBVTT\n\n'+''.join(f'{timestamp(s)} --> {timestamp(e)}\n{t}\n\n' for s,e,t in cues),encoding='utf-8')
 print(voice,rate,round(offset/hz,2),'s,',len(cues),'captions;',str(target))
asyncio.run(main())
