# Titles in spoken order; each shot references a strictly bounded motion clip.
clips={
 'stage':('stage',.30,5.63),'reception':('lounge',13.74,16.84),'expo':('expo',.20,4.35),'host':('expo',4.9,7.45),
 'linen':('intro',.2,4.65),'flowers':('intro',5.5,9.5),'ballroom':('intro',10.3,15.15),'doors':('intro',15.9,20.3),
 'garden':('intro',20.8,26.3),'camera':('intro',27.05,30.65),'dessert':('intro',31.2,35.8),'service':('intro2',19.89,22.6),
 'restaurant':('gourmet',20.25,23.8),'chef':('gourmet',14,16.55),'coffee':('pour',.8,6.7),
 'brunch':('gourmet',20.35,23.86),'mimosas':('morning',4.75,7.85),'dj':('playing',3,8.9),
 'palm':('palm',.8,6.9),'spa':('morning',12.55,16.25),'network':('morning',17.6,20.5),
 'print':('print',.08,3.89),'demo':('demo',.06,3.91),'identity':('identity',.08,3.91),'island':('island',.05,3.92),
 'backdrop':('backdrop',.05,3.9),'install':('install',.05,3.93),'sample':('sampling',.05,3.93)}
# NAME, title, second line, concept label or compact diagram, clips
plans={}
pages={}

plans['full-production']=[
 ('Event Production','What should guests','take away?',None,'linen ballroom'),
 ('The production plan','Discover.','Design the scope.','run|Confirm event goals|Map the handoffs|Build the system','camera reception'),
 ('The production team','A clear role','for every partner.','crew|Catering & décor|Multimedia|Staffing & logistics','service camera garden'),
 ('Field experience','250+ events each year','small and midsize',None,'dessert doors'),
 ('Included in full production','One shared','event plan.','app|Guest registration|Check-in|Crew assignments','reception expo'),
 ('Your next event','Request a','production proposal.','url|vnvevents.com/event-production','garden linen')]
plans['corporate-events']=[
 ('Event Production','Your keynote','starts at nine.',None,'reception ballroom'),
 ('A corporate program','Who calls','the handoff?','run|08:00   Breakfast|08:50   Room reset|09:00   Keynote','camera doors'),
 ('Vendor coordination','Service pauses.','The mic goes live.','crew|Catering & décor|Audio & video|Staffing & logistics','service reception camera'),
 ('Field experience','250+ events each year','small and midsize',None,'expo chef'),
 ('Included in full production','One shared','production plan.','app|Registration|Individual check-in|Crew assignments','host doors'),
 ('Event Production','Request a','production proposal.','url|vnvevents.com/event-production','ballroom reception')]
plans['cause-on-cue']=[
 ('Nonprofit Partnerships','Give the mission','the microphone.',None,'ballroom reception'),
 ('Cause on Cue','Plan around','the mission.','run|Program|Sponsor opportunities|Volunteer roles','camera doors'),
 ('Fundraiser production','A place for','every partner.','crew|Guest welcome|Sponsor handoff|Program cue','garden service camera'),
 ('Field experience','250+ events each year','small and midsize',None,'linen dessert'),
 ('Approved nonprofit partnerships','VNV-Q is','included.','app|Register guests|Coordinate volunteers|Track sponsor activity','reception flowers'),
 ('Cause on Cue','Explore a nonprofit','partnership.','url|vnvevents.com/nonprofit-partnerships','doors garden')]
plans['brand-activation']=[
 ('Brand Experiences & Activation','Where should that','first meeting happen?',None,'host demo'),
 ('01 / Existing event','Activate at an','existing event.','run|Align with the organizer|Guide the interaction|Follow up','expo sample demo'),
 ('02 / Partnership','Partner with','our experiences.','run|Find a fit|Confirm availability|Agree on benefits','network brunch stage'),
 ('03 / Brand-owned event','Create your own','brand event.','crew|Product launches|Customer showcases|Corporate gatherings','ballroom reception camera'),
 ('Production experience','250+ events each year','small and midsize',None,'service host'),
 ('Your next campaign','Create your','brand experience.','url|vnvevents.com/sponsor-activation-production','demo ballroom')]
plans['original-experiences']=[
 ('Original Experiences','How should','the room feel?',None,'brunch dj'),
 ('Mommy & Daddy Break Club','A morning with','room to breathe.',None,'spa coffee mimosas'),
 ('Retro Glam Sessions','One night.','One decade.','design|Stage lighting|DJ session|Photo moments','dj stage'),
 ('Your brand at an edition','Work with','our producers.','crew|Product sampling|Sponsorship|Approved activation','garden camera service'),
 ('Field experience','250+ events each year','small and midsize',None,'linen dessert'),
 ('Original Experiences','Explore the editions.','Ask about partnering.','url|vnvevents.com/vnv-events-productions','palm network')]
plans['morning-club']=[
 ('Mommy & Daddy Break Club','A morning that','feels like a break.',None,'coffee brunch'),
 ('The morning','Move slowly.','Stay for brunch.',None,'palm spa mimosas'),
 ('Your invitation','Make time','to connect.',None,'network garden'),
 ('Behind the morning','A host for','every detail.','crew|Catering & décor|Multimedia & hosts|Guest arrivals','linen dj chef'),
 ('Our producers','250+ events each year','small and midsize',None,'service dessert'),
 ('Priority invitations','Join the free','priority list.','url|Mommy & Daddy Break Club','brunch palm')]
pages.update({'full-production':'Event Production','corporate-events':'Event Production','cause-on-cue':'Nonprofit Partnerships','brand-activation':'Brand Experiences & Activation','original-experiences':'Original Experiences','morning-club':'Mommy & Daddy Break Club'})
