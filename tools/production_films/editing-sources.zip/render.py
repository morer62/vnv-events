import os, sys, subprocess as sp, json, shutil, math, time
from functools import lru_cache
from pathlib import Path
from PIL import Image,ImageFont,ImageDraw
import numpy as np
from sources import sources,hub
from plan import plans,clips,pages
D=Path(__file__).parent; TMP=D.parent
OUT=Path(os.environ['VNV_FILM_OUTPUT']); OUT.mkdir(exist_ok=True,parents=True)

W,H,F=1280,720,24
def args(x):return [str(i) for i in x]
def run(lst):sp.run(args(lst),check=True)
def prog(lst,**kwargs):return sp.Popen(args(lst),**kwargs)
def ff():return ['ffmpeg','-hide_banner','-loglevel','error','-y']
def ease(t):t=max(0,min(1,t));return t*t*(3-2*t)
@lru_cache(None)
def font(size,f='segoeui.ttf'):return ImageFont.truetype('C:/Windows/Fonts/'+f,size)
def drawtext(dr,xy,s,sz,col='white',f='segoeui.ttf'):dr.text(xy,s,font=font(sz,f),fill=col,anchor='lt')
def spaced(dr,xy,s,sz,col,space=2.2):
 x,y=xy;f=font(sz,'segoeuib.ttf')
 for c in s.upper():dr.text((round(x),y),c,font=f,fill=col,anchor='lt');x+=f.getlength(c)+space
pal={'full-production':('#87dfcd',(7,26,29)),'cause-on-cue':('#ffcd83',(18,23,43)),'corporate-events':('#eac78a',(5,28,26)),'brand-activation':('#97e6d7',(6,28,35)),'original-experiences':('#f5ce92',(39,25,34)),'morning-club':('#ffddba',(48,35,36))}
@lru_cache(None)
def gradient(slug):
 c=pal[slug][1];y,x=np.ogrid[:H,:W]
 a=np.clip(.82*(1-x/W)**1.40+.16*(y/H)**1.8+.09,0,.95)
 ar=np.empty((H,W,4),dtype='uint8');ar[:,:,:3]=c;ar[:,:,3]=255*a
 return Image.fromarray(ar)
@lru_cache(None)
def layer(slug,scene):
 eyebrow,title,second,detail,_=plans[slug][scene];accent,c=pal[slug]
 im=Image.new('RGBA',(W,220));dr=ImageDraw.Draw(im)
 spaced(dr,(2,2),eyebrow,19,accent)
 size=69; italic='georgiai.ttf'; reg='georgia.ttf';limit=1120 if not detail or detail.startswith('url') else 710
 while max(font(size,reg).getlength(title),font(size,italic).getlength(second))>limit:size-=1
 drawtext(dr,(0,42),title,size,'#fff9ed',reg);drawtext(dr,(0,48+size),second,size,accent,italic)
 if detail and detail.startswith('url'):
  drawtext(dr,(2,64+size*2),detail.split('|')[1],22,'#fff9ed','segoeuib.ttf')
 return im
@lru_cache(None)
def panel(slug,scene):
 info=plans[slug][scene][3]
 if not info or info.startswith('url'):return
 mode,*items=info.split('|'); panel=Image.new('RGBA',(401,236)); dr=ImageDraw.Draw(panel)
 dr.rounded_rectangle((0,0,400,234),radius=18,fill=(15,32,39,235),outline=(198,207,192,160),width=1)
 name={'app':'VNV-Q   /   EVENT SOFTWARE','run':'RUN OF SHOW','crew':'PRODUCTION DESK','design':'DESIGN & BUILD'}[mode];ac=pal[slug][0]
 spaced(dr,(24,20),name,13,ac,1.3)
 for n,label in enumerate(items):
  yy=65+n*54;dr.line((22,yy-11,376,yy-11),fill=(151,177,170,65),width=1)
  drawtext(dr,(60,yy),label,21,'#f8f4e9','seguisb.ttf')
 return panel
def over(bg,img,x,y,opacity=1):
 if opacity<=0:return
 a=img.getchannel('A')
 if opacity<.995:a=a.point(lambda v:round(v*opacity))
 bg.paste(img,(int(x),int(y)),a)
def motion(bg,slug,scene,t,dur,globalt):
 ac=pal[slug][0]; bg.paste(gradient(slug),(0,0),gradient(slug))
 dr=ImageDraw.Draw(bg);over(bg,mark,62,44)
 # Deliberately leave the lower caption safe area empty.
 reveal=ease((t+.08)/.48);gone=1 if scene==5 else ease((dur-t+.02)/.20);a=min(reveal,gone)
 yy=294 if scene==5 else 329
 over(bg,layer(slug,scene),65+int(20*(1-reveal)),yy,a)
 if a>.01:dr.line((67,yy-18,67+int(143*a),yy-18),fill=ac,width=2)
 panelimg=panel(slug,scene)
 if panelimg:
  pa=min(ease((t-.45)/.6),gone);xx=815+int(24*(1-pa));py=319
  over(bg,panelimg,xx,py,pa)
  if pa>.8:
   for n in range(3):
    y=py+77+54*n;x=xx+37; pulse=ease((t-.85-n*max(.68,(dur-1.9)/3))/.36)
    dr.ellipse((x-7,y-7,x+7,y+7),outline=ac,width=1)
    if pulse>.01:dr.ellipse((x-int(5*pulse),y-int(5*pulse),x+int(5*pulse),y+int(5*pulse)),fill=ac)
 # A small marker in the live run sheet connects the scenes.
 if scene==5 and dur-t<.38:bg=Image.blend(Image.new('RGB',(W,H),pal[slug][1]),bg,ease((dur-t)/.38))
 if scene==0 and t<.20:bg=Image.blend(Image.new('RGB',(W,H),pal[slug][1]),bg,ease((t+.04)/.20))
 return bg
mark=Image.open(D/'vnv-mark.png').convert('RGBA')
def decoder(key,count,w=W,h=H,look=None):
 name,ss,end=clips[key]; source=sources[name];wanted=count/F
 span=min(end-ss,wanted+.31)
 start=ss
 # Select a complete source window, retaining motion across every dissolve.
 orient='scale='+str(w)+':'+str(h)+':force_original_aspect_ratio=increase,crop='+str(w)+':'+str(h)
 if name=='gourmet':orient='crop=720:406:0:335,scale='+str(w)+':'+str(h)
 # The approved lounge scene has no lower titles within this crop.
 if name in ('expo','morning'):orient='crop=iw*.89:ih*.89:iw*.082:ih*.085,'+orient
 if name=='lounge':orient='crop=1120:630:160:0,scale='+str(w)+':'+str(h)
 vf='trim=duration='+str(span)+',setpts='+str((wanted+.12)/span)+'*(PTS-STARTPTS),fps=24,'+orient+',setsar=1'
 return prog(ff()+['-threads','1','-ss',str(start),'-i',source,'-an','-vf',vf,'-frames:v',count,'-pix_fmt','rgb24','-c:v','rawvideo','-threads','1','-f','rawvideo','pipe:1'],stdout=sp.PIPE)
def enc(path,w,h,fps=24,crf=21,rate='2800k'):
 return prog(ff()+['-f','rawvideo','-pix_fmt','rgb24','-s',f'{w}x{h}','-r',fps,'-i','pipe:0','-an','-c:v','libx264','-preset','veryfast','-crf',crf,'-maxrate',rate,'-bufsize','4500k','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',path],stdin=sp.PIPE)
def read(proc,w,h): 
 raw=proc.stdout.read(w*h*3)
 if len(raw)!=w*h*3:raise RuntimeError(f'Source ended before the complete cut ({len(raw)} bytes)')
 return Image.frombytes('RGB',(w,h),raw)
def shots(slug):
 timing=json.loads((D/(slug+'-timings.json')).read_text(encoding='utf-8-sig'))
 for si,entry in enumerate(timing):
  names=plans[slug][si][-1].split()
  start=round(F*entry['start']);end=math.ceil(F*entry['end']) if si==5 else round(F*entry['end'])
  for ni,key in enumerate(names):
   s=start+round((end-start)*ni/len(names));e=start+round((end-start)*(ni+1)/len(names))
   yield si,key,start,end,s,e
def motionfilm(slug):
 scratch=D/(slug+'-vision.mp4');encp=enc(scratch,W,H);tail=[];rows=list(shots(slug))
 try:
  for index,(sc,name,bs,be,s,e) in enumerate(rows):
   n=e-s;handle=6 if index+1<len(rows) else 0;p=decoder(name,n+handle);tailout=[]
   try:
    for frame in range(n+handle):
     bg=read(p,W,H)
     if frame>=n:tailout.append(bg);continue
     if frame<len(tail):bg=Image.blend(tail[frame],bg,ease((frame+1)/(len(tail)+1)))
     t=(s+frame-bs)/F;pic=motion(bg,slug,sc,t,(be-bs)/F,(s+frame)/F)
     encp.stdin.write(pic.tobytes())
     if (sc==0 and frame==round(n*.64) and index==0):
      pic.save(OUT/(slug+'.webp'),quality=86,method=4)
    tail=tailout
   finally:p.stdout.close();p.wait()
 finally:encp.stdin.close();rc=encp.wait()
 if rc:raise RuntimeError('Encoder failed')
 end=rows[-1][-1]/F
 music=Path(os.environ['VNV_FILM_LIBRARY'])/'Service films v8'/'music'
 bed=music/(slug+'-bed.wav')
 if not bed.exists():bed=music/(slug+'-music.wav')
 # Both sources are independently levelled. Speech leads and music stays audible through the tail.
 mix=f'[1:a]loudnorm=I=-17:TP=-2:LRA=8,aresample=48000,aformat=channel_layouts=stereo,apad[vo];[2:a]atrim=duration={end:.4f},loudnorm=I=-29:TP=-6:LRA=7,aresample=48000,aformat=channel_layouts=stereo,afade=t=in:d=0.35,afade=t=out:st={end-1.0:.4f}:d=1[m];[vo][m]amix=duration=longest:normalize=0,alimiter=limit=0.88:level=0,atrim=duration={end:.4f}[out]'
 run(ff()+['-i',scratch,'-i',D/(slug+'-voice.wav'),'-stream_loop','-1','-i',bed,'-filter_complex',mix,'-map','0:v','-map','[out]','-c:v','copy','-c:a','aac','-b:a','144k','-ar','48000','-movflags','+faststart',OUT/(slug+'.mp4')])
 scratch.unlink();shutil.copyfile(D/(slug+'-en.vtt'),OUT/(slug+'-en.vtt'))
def preview(slug):
 playlist={'full-production':'camera linen ballroom','corporate-events':'reception camera expo','cause-on-cue':'service ballroom garden','brand-activation':'demo network ballroom','original-experiences':'brunch dj garden','morning-club':'coffee palm brunch'}[slug].split()
 dst=OUT/(slug+'-preview.mp4');p=enc(dst,960,540,24,23,'1450k');tail=[];n=64
 for i,name in enumerate(playlist):
  q=decoder(name,n+6,960,540);out=[]
  for f in range(n+6):
   frame=read(q,960,540)
   if f>=n:out.append(frame);continue
   if f<len(tail):frame=Image.blend(tail[f],frame,ease((f+1)/7))
   if i==0 and f==22:frame.save(OUT/(slug+'-preview.webp'),quality=84)
   p.stdin.write(frame.tobytes())
  q.stdout.close();q.wait();tail=out
 p.stdin.close()
 if p.wait():raise RuntimeError('preview encode failed')
 run(ff()+['-i',dst,'-an','-vf','crop=ih*4/5:ih,scale=432:540','-c:v','libx264','-crf','23','-maxrate','850k','-bufsize','1500k','-threads','2','-movflags','+faststart',OUT/(slug+'-preview-mobile.mp4')])
if __name__=='__main__':
 for slug in sys.argv[1:]:
  print('Rendering',slug,flush=True);motionfilm(slug);
  if slug=='brand-activation':preview(slug)
  print('Finished',slug,flush=True)



