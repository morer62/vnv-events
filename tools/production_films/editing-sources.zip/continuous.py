from pathlib import Path
import ast,asyncio,sys,time,json,re,bisect,difflib,html,functools,math,wave,subprocess
import edge_tts,hashlib
D=Path(__file__).parent
tmp=D/'voice-helpers'
align=ast.parse((tmp/'neural.py').read_text('utf-8-sig'))
exec(compile(ast.Module(body=[f for f in align.body if isinstance(f,ast.FunctionDef) and f.name in ('norm','syllable_align','timestamp')],type_ignores=[]),'alignment','exec'))
standard_norm=norm
def norm(txt):
 if txt.strip('.,!?').lower()=='vnv-q':return 'vnvcue'
 if txt.strip('.,!?').lower()=='ophyra':return 'ofeera'
 return standard_norm(txt)
src=(tmp/'captions.py').read_text('utf-8-sig')
exec(src[src.index('weak=set('):src.index('for script in sorted(')])
scripts=json.loads((D/'scripts.json').read_text(encoding='utf-8-sig'))
async def job(slug,scenes):
 full=' '.join(scenes)
 said=full.replace('VNV-Q','V N V Cue').replace('VNV','V N V').replace('Ophyra','Ofeera')
 mp3=D/(slug+'-continuous.mp3');meta=D/(slug+'-words.jsonl')
 key=D/(slug+'-read.sha256');digest=hashlib.sha256(said.encode()).hexdigest()
 if not (key.exists() and key.read_text('ascii').strip()==digest and mp3.exists() and meta.exists() and meta.stat().st_size>500 and mp3.stat().st_size>5000):
  for x in range(5):
   try:
    await edge_tts.Communicate(said,'en-US-AndrewNeural',rate='-9%',boundary='WordBoundary',connect_timeout=15,receive_timeout=60).save(str(mp3),str(meta));break
   except Exception:
    if x==4:raise
    await asyncio.sleep(2+2*x)
 key.write_text(digest+'\n','ascii')
 words=[json.loads(l) for l in meta.read_text('utf-8').splitlines() if l];tokens=syllable_align(full,words)
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(mp3),'-ar','24000','-ac','1','-f','s16le','pipe:1'])
 first=max(0,int((tokens[0][1]-.11)*24000));last=min(len(raw)//2,round((tokens[-1][2]+.38)*24000));duration=(last-first)/24000
 with wave.open(str(D/(slug+'-voice.wav')),'wb') as w:
  w.setparams((1,2,24000,0,'NONE',''));w.writeframes(raw[first*2:last*2])
 tokens=[(w,a-first/24000,b-first/24000) for w,a,b in tokens];timeline=[];capt=[];i=0
 for n,s in enumerate(scenes):
  st=0 if not n else timeline[-1]['end'];j=i+len(s.split());final=duration if n==len(scenes)-1 else (tokens[j-1][2]+tokens[j][1])/2
  timeline.append(dict(id=str(n+1),text=s,start=round(st,5),end=round(final,5)))
  for a,b,msg in group(tokens[i:j]):capt.append((a,b,msg))
  i=j
 assert i==len(tokens) and all(a[1]<=b[0] for a,b in zip(capt,capt[1:]))
 assert ' '.join(' '.join(m.split()) for _,_,m in capt)==full
 for suffix,data in [('timings.json',json.dumps(timeline,ensure_ascii=False,indent=2)),('en.vtt','WEBVTT\n\n'+'\n\n'.join(f'{timestamp(a)} --> {timestamp(b)}\n{m}' for a,b,m in capt)+'\n')]:
  (D/(slug+'-'+suffix)).write_text(data,'utf-8')
 print(slug,round(duration,2),'seconds',len(capt),'captions',flush=True)
async def main():
 sem=asyncio.Semaphore(3)
 async def t(k):
  async with sem:await job(k,scripts[k])
 await asyncio.gather(*(t(s) for s in scripts))
asyncio.run(main())
