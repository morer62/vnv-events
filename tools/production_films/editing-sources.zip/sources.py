import os
from pathlib import Path
import subprocess, io
from PIL import Image,ImageDraw
h=Path.home(); hub=Path(os.environ['VNV_FILM_LIBRARY']); a=Path(os.environ['VNV_VIDEO_ASSETS']); m=hub/'Corporate'; b=Path(os.environ['VNV_BREAK_RUSHES']); e=hub/'Activation'; g=e/'CGI'
sources={'intro':a/'intro.mp4','intro2':a/'intro_vnv.mp4','expo':m/'expo-source.mp4','lounge':m/'lounge-source.mp4','morning':m/'morning-source.mp4','palm':b/'palm.mp4','pour':b/'pour.mp4','playing':b/'playing.mp4','identity':e/'identity.mp4','print':e/'print.mp4','demo':e/'demo.mp4','backdrop':g/'backdrop.mp4','island':g/'island.mp4','sampling':g/'sampling.mp4','install':g/'install.mp4','gourmet':a.parent/'videos/gourmet-to-go-launch-30s.mp4','fb':hub/'Software revision/edition-v7/hospitality-actions.mp4'}
sources['stage']=Path(os.environ['VNV_FILM_LIBRARY'])/'Service films v8'/'retro-stage-band.mp4'
def sheet():
 rows=[]
 for k,f in sources.items():
  dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(f)]))
  print(k,round(dur,2),f)
  times=[.35+i*2.1 for i in range(18) if .35+i*2.1<dur-.1]
  for start in range(0,len(times),9):
   row=Image.new('RGB',(9*120,87)); draw=ImageDraw.Draw(row)
   for j,t in enumerate(times[start:start+9]):
    bits=subprocess.check_output(['ffmpeg','-loglevel','error','-ss',str(t),'-i',str(f),'-frames:v','1','-vf','scale=120:65','-f','image2pipe','-c:v','mjpeg','-threads','1','-']);ok=bool(bits)
    if ok:
     row.paste(Image.open(io.BytesIO(bits)),(j*120,0));draw.text((j*120,66),k+' '+str(round(t,1)),fill='white')
   rows.append(row)
  pass
 for i in range(0,len(rows),8):
  out=Image.new('RGB',(1080,87*min(8,len(rows)-i)))
  for j,row in enumerate(rows[i:i+8]):out.paste(row,(0,j*87))
  out.save(Path(__file__).parent/f'sources{i}.jpg')
if __name__=='__main__':sheet()



